//
//  bankaccount.swift
//  OOP
//
//  Created by MacStudent on 2017-10-11.
//  Copyright © 2017 Johnson. All rights reserved.
//

import Foundation

class bankaccount
    
{
    public private(set) var balance : Double
    public private(set) var interest : Double
    
    init() {
        balance  = 0.0
        interest = 0.0
    }
    
    init(initialBalance : Double , initialInterest : Double)
    {
    
    balance = initialBalance
    interest = initialInterest
        
    }
    
    func deposit( amount : Double) -> Double {
        
        balance = balance + amount
        
        return balance
    }
    
    func withdraw( amount : Double) -> Double
    {
        
    balance = balance - amount
        return balance
        
    }
    
    func addInterest() -> Double
{
    balance = balance + balance * interest;
    return balance
    
    }
    
    func getbalance() -> Double {
        return balance
    }
}
