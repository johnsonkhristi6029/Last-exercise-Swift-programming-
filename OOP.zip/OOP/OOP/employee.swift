//
//  employee.swift
//  OOP
//
//  Created by Johnson on 2017-10-09.
//  Copyright © 2017 Johnson. All rights reserved.
//

import Foundation

class Employee
{
    var name: String
    var idnumber: Int
    var department:String
    var position:String

    init(emp_name : String ,Id : Int , dept : String , emp_position : String)
    {
        name = emp_name
        idnumber = Id
        department = dept
        position = emp_position
        
    }
    
    init(emp_name :String ,Id : Int)
    {
        name  = emp_name
        idnumber = Id
        department = ""
        position = ""
    }
    
    init() {
        
        name = " "
        idnumber = 0
        department = ""
        position = ""
    }
    
    
    
    
}
