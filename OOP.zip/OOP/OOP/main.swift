//
//  main.swift
//  OOP
//
//  Created by Johnson on 2017-10-09.
//  Copyright © 2017 Johnson. All rights reserved.
//

import Foundation

// Exercise 1
var employee = Employee ()

print("Empoyee data are \n  Name : \(employee.name) ,Id : \(employee.idnumber) , Department :\(employee.department) , Position : \(employee.position)  ")

var employee1 = Employee(emp_name : "Susan Meyers ",Id :47899  , dept : "Accounting" , emp_position : "Vice President")

print("Employee name :\(employee1.name) , Employee Id : \(employee1.idnumber),Employee Dept : \(employee1.department) , Employee Position : \(employee1.position)")

var employee2 = Employee(emp_name : "Mark Jones",Id : 39119 ,dept : "IT" , emp_position : "Programmer ")
print("Employee name :\(employee2.name) , Employee Id : \(employee2.idnumber),Employee Dept : \(employee2.department) , Employee Position : \(employee2.position)")


var employee3 = Employee(emp_name : "Joy Rodgers",Id : 81774 ,dept : "Manufacturing" , emp_position : "Engineer ")
print("Employee name :\(employee3.name) , Employee Id : \(employee3.idnumber),Employee Dept : \(employee3.department) , Employee Position : \(employee3.position)")


// Exercise 3

var workerclass = ProductionWorker(nn: "John" , emplo_number : 111 ,hrdate:"2017-11-10" , shift_name : 2, payrate : 11.40 )

print ("Employee name \(workerclass.name)  has employee number \(workerclass.employee_number) join job on \(workerclass.hire_date) working in shift \(workerclass.shift) with pay scale of \(workerclass.pay_rate)")
